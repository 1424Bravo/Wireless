RFID sniffer uses USRP (A software defined radio) and GnuRadio to sniff the communication between and (C)RFID tag and an RFID reader. 
Then the user can user the matlab script to decode all the messages that were exchanged between the tag and the reader. 
